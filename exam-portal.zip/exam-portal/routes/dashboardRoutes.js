const express = require('express');
const dashboardController = require('../controllers/dashboardController');
const authMiddleware = require('../middleware/authMiddleware');

const router = express.Router();

router.use(authMiddleware.protect);

router.get('/teacher', authMiddleware.authorize('teacher'), dashboardController.getTeacherDashboard);
router.get('/student', authMiddleware.authorize('student'), dashboardController.getStudentDashboard);
router.get('/teacher/create-exam', authMiddleware.authorize('teacher'), dashboardController.getCreateExamPage);

module.exports = router;
