const express = require('express');
const examTakingController = require('../controllers/examTakingController');
const authMiddleware = require('../middleware/authMiddleware');

const router = express.Router();

router.use(authMiddleware.protect);

router.get('/take/:id', authMiddleware.authorize('student'), examTakingController.getTakeExamPage);
router.post('/submit', authMiddleware.authorize('student'), examTakingController.submitExam);
router.get('/result/:id', examTakingController.getResultPage);

module.exports = router;
