const express = require('express');
const router = express.Router();
const studentController = require('../controllers/studentController');
const { protect, authorize } = require('../middleware/authMiddleware');

router.use(protect);
router.use(authorize('teacher'));

router.get('/', studentController.getAllStudents);
router.patch('/:id/block', studentController.toggleBlockStatus);

module.exports = router;
