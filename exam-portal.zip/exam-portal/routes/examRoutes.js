const express = require('express');
const examController = require('../controllers/examController');
const authMiddleware = require('../middleware/authMiddleware');

const router = express.Router();

router.use(authMiddleware.protect);

router.route('/')
    .get(examController.getAllExams)
    .post(authMiddleware.authorize('teacher'), examController.createExam);

router.route('/:id')
    .get(examController.getExam)
    .delete(authMiddleware.authorize('teacher'), examController.deleteExam);

router.get('/:id/stats', authMiddleware.authorize('teacher'), examController.getExamStats);

module.exports = router;
