#!/bin/bash

BASE_URL="http://localhost:3000"
COOKIE_FILE="cookies.txt"

echo "--- 1. Register Teacher ---"
curl -s -c $COOKIE_FILE -X POST "$BASE_URL/auth/register" \
    -H "Content-Type: application/json" \
    -d '{"name":"Teacher Curl","email":"teacher_curl@test.com","password":"password123","role":"teacher"}' \
    -w "\nStatus: %{http_code}\n"

echo -e "\n--- 2. Login Teacher ---"
curl -s -c $COOKIE_FILE -b $COOKIE_FILE -X POST "$BASE_URL/auth/login" \
    -H "Content-Type: application/json" \
    -d '{"email":"teacher_curl@test.com","password":"password123"}' \
    -w "\nStatus: %{http_code}\n"

echo -e "\n--- 3. Create Exam ---"
# Constructing a complex JSON for exam creation
# We need to escape the inner quotes for the JSON string
QUESTIONS="[{\\\"questionText\\\":\\\"What is 2+2?\\\",\\\"options\\\":[\\\"3\\\",\\\"4\\\",\\\"5\\\",\\\"6\\\"],\\\"correctOption\\\":1,\\\"marks\\\":5}]"

curl -s -b $COOKIE_FILE -X POST "$BASE_URL/api/exams" \
    -H "Content-Type: application/json" \
    -d "{\"title\":\"Curl Exam\",\"description\":\"Created via Curl\",\"duration\":10,\"questions\":\"$QUESTIONS\"}" \
    -w "\nStatus: %{http_code}\n"

echo -e "\n--- 4. Logout ---"
curl -s -b $COOKIE_FILE -X GET "$BASE_URL/auth/logout" -w "\nStatus: %{http_code}\n"

echo -e "\n--- 5. Register Student ---"
curl -s -c $COOKIE_FILE -X POST "$BASE_URL/auth/register" \
    -H "Content-Type: application/json" \
    -d '{"name":"Student Curl","email":"student_curl@test.com","password":"password123","role":"student"}' \
    -w "\nStatus: %{http_code}\n"

echo -e "\n--- 5b. Login Student (in case register failed) ---"
curl -s -c $COOKIE_FILE -b $COOKIE_FILE -X POST "$BASE_URL/auth/login" \
    -H "Content-Type: application/json" \
    -d '{"email":"student_curl@test.com","password":"password123"}' \
    -w "\nStatus: %{http_code}\n"

echo -e "\n--- 6. Get Student Dashboard (Check for Exam) ---"
curl -s -b $COOKIE_FILE -X GET "$BASE_URL/dashboard/student" -w "\nStatus: %{http_code}\n" | grep "Curl Exam" > /dev/null
if [ $? -eq 0 ]; then
    echo "Success: Found 'Curl Exam' in dashboard"
else
    echo "Failure: 'Curl Exam' not found in dashboard"
fi

rm $COOKIE_FILE
