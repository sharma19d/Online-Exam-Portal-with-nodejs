const Exam = require('../models/Exam');
const User = require('../models/User');
const Result = require('../models/Result');

exports.createExam = async (req, res) => {
    try {
        const { title, description, duration, questions } = req.body;

        const newExam = await Exam.create({
            title,
            description,
            duration,
            questions: JSON.parse(questions), // Assuming questions are sent as a JSON string
            createdBy: req.user._id
        });

        res.status(201).json({
            status: 'success',
            data: {
                exam: newExam
            }
        });
    } catch (err) {
        res.status(400).json({
            status: 'fail',
            message: err.message
        });
    }
};

exports.getAllExams = async (req, res) => {
    try {
        const exams = await Exam.find({ isActive: true }).populate('createdBy', 'name');

        res.status(200).json({
            status: 'success',
            results: exams.length,
            data: {
                exams
            }
        });
    } catch (err) {
        res.status(400).json({
            status: 'fail',
            message: err.message
        });
    }
};

exports.getExam = async (req, res) => {
    try {
        const exam = await Exam.findById(req.params.id);

        if (!exam) {
            return res.status(404).json({
                status: 'fail',
                message: 'No exam found with that ID'
            });
        }

        res.status(200).json({
            status: 'success',
            data: {
                exam
            }
        });
    } catch (err) {
        res.status(400).json({
            status: 'fail',
            message: err.message
        });
    }
};

exports.deleteExam = async (req, res) => {
    try {
        const exam = await Exam.findByIdAndDelete(req.params.id);

        if (!exam) {
            return res.status(404).json({
                status: 'fail',
                message: 'No exam found with that ID'
            });
        }

        res.status(204).json({
            status: 'success',
            data: null
        });
    } catch (err) {
        res.status(400).json({
            status: 'fail',
            message: err.message
        });
    }
};

exports.getExamStats = async (req, res) => {
    try {
        const examId = req.params.id;
        const exam = await Exam.findById(examId);

        if (!exam) {
            return res.status(404).render('error', { error: 'Exam not found' });
        }

        // Get all students
        const students = await User.find({ role: 'student' }).select('name email');

        // Get all results for this exam
        const results = await Result.find({ exam: examId }).populate('student', 'name email');

        const takenStudentIds = results.map(r => r.student._id.toString());

        const stats = students.map(student => {
            const result = results.find(r => r.student._id.toString() === student._id.toString());
            return {
                student,
                hasTaken: !!result,
                score: result ? result.score : null,
                totalMarks: result ? result.totalMarks : null
            };
        });

        const takenCount = results.length;
        const pendingCount = students.length - takenCount;

        res.render('exam_stats', {
            exam,
            stats,
            takenCount,
            pendingCount
        });
    } catch (err) {
        console.error(err);
        res.status(500).render('error', { error: 'Server Error' });
    }
};
