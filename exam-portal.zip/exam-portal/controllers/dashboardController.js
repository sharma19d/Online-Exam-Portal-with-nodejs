const Exam = require('../models/Exam');
const Result = require('../models/Result');

exports.getTeacherDashboard = async (req, res) => {
    try {
        const exams = await Exam.find({ createdBy: req.user._id }).sort('-createdAt');
        const studentCount = await require('../models/User').countDocuments({ role: 'student' });
        res.render('dashboard_teacher', { user: req.user, exams, studentCount });
    } catch (err) {
        res.status(500).render('error', { message: 'Error loading dashboard' });
    }
};

exports.getStudentDashboard = async (req, res) => {
    try {
        const exams = await Exam.find({ isActive: true }).sort('-createdAt');
        const results = await Result.find({ student: req.user._id }).populate('exam');
        res.render('dashboard_student', { user: req.user, exams, results });
    } catch (err) {
        res.status(500).render('error', { message: 'Error loading dashboard' });
    }
};

exports.getCreateExamPage = (req, res) => {
    res.render('create_exam', { user: req.user });
};
