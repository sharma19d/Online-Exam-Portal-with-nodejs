const User = require('../models/User');

exports.getAllStudents = async (req, res) => {
    try {
        const students = await User.find({ role: 'student' }).select('-password');
        res.render('manage_students', { students });
    } catch (err) {
        console.error(err);
        res.status(500).render('error', { error: 'Server Error' });
    }
};

exports.toggleBlockStatus = async (req, res) => {
    try {
        const student = await User.findById(req.params.id);
        if (!student) {
            return res.status(404).json({ message: 'Student not found' });
        }

        student.isBlocked = !student.isBlocked;
        await student.save();

        res.status(200).json({
            message: `Student ${student.isBlocked ? 'blocked' : 'unblocked'} successfully`,
            isBlocked: student.isBlocked
        });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Server Error' });
    }
};
