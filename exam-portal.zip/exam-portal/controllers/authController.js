const User = require('../models/User');
const jwt = require('jsonwebtoken');

const signToken = (id) => {
    return jwt.sign({ id }, process.env.JWT_SECRET, {
        expiresIn: '30d'
    });
};

const createSendToken = (user, statusCode, res) => {
    const token = signToken(user._id);

    const cookieOptions = {
        expires: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000),
        httpOnly: true
    };

    res.cookie('token', token, cookieOptions);

    user.password = undefined;

    if (user.role === 'teacher') {
        res.redirect('/dashboard/teacher');
    } else {
        res.redirect('/dashboard/student');
    }
};

exports.register = async (req, res) => {
    try {
        const { name, email, password, role } = req.body;

        const newUser = await User.create({
            name,
            email,
            password,
            role
        });

        createSendToken(newUser, 201, res);
    } catch (err) {
        res.status(400).render('register', { error: err.message });
    }
};

exports.login = async (req, res) => {
    try {
        const { email, password } = req.body;

        if (!email || !password) {
            return res.status(400).render('login', { error: 'Please provide email and password' });
        }

        const user = await User.findOne({ email }).select('+password');

        if (!user || !(await user.matchPassword(password))) {
            return res.status(401).render('login', { error: 'Incorrect email or password' });
        }

        if (user.isBlocked) {
            return res.status(403).render('login', { error: 'Your account has been blocked. Please contact the administrator.' });
        }

        createSendToken(user, 200, res);
    } catch (err) {
        res.status(400).render('login', { error: err.message });
    }
};

exports.logout = (req, res) => {
    res.cookie('token', 'loggedout', {
        expires: new Date(Date.now() + 10 * 1000),
        httpOnly: true
    });
    res.redirect('/auth/login');
};

exports.getLoginPage = (req, res) => {
    res.render('login');
};

exports.getRegisterPage = (req, res) => {
    res.render('register');
};
