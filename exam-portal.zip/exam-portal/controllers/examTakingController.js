const Exam = require('../models/Exam');
const Result = require('../models/Result');

exports.getTakeExamPage = async (req, res) => {
    try {
        const exam = await Exam.findById(req.params.id);

        if (!exam) {
            return res.status(404).render('error', { message: 'Exam not found' });
        }

        // Check if already taken
        const existingResult = await Result.findOne({ student: req.user._id, exam: exam._id });
        if (existingResult) {
            return res.redirect(`/exam/result/${existingResult._id}`);
        }

        res.render('take_exam', { user: req.user, exam });
    } catch (err) {
        res.status(500).render('error', { message: 'Error loading exam' });
    }
};

exports.submitExam = async (req, res) => {
    try {
        const { examId, answers } = req.body; // answers: { questionId: selectedOptionIndex }
        const exam = await Exam.findById(examId);

        if (!exam) {
            return res.status(404).json({ status: 'fail', message: 'Exam not found' });
        }

        let score = 0;
        let totalMarks = 0;
        const resultAnswers = [];

        exam.questions.forEach(question => {
            const selectedOption = parseInt(answers[question._id]);
            const isCorrect = selectedOption === question.correctOption;

            if (isCorrect) {
                score += question.marks;
            }
            totalMarks += question.marks;

            resultAnswers.push({
                questionId: question._id,
                selectedOption,
                isCorrect
            });
        });

        const result = await Result.create({
            student: req.user._id,
            exam: exam._id,
            score,
            totalMarks,
            answers: resultAnswers
        });

        res.status(200).json({
            status: 'success',
            data: {
                resultId: result._id
            }
        });
    } catch (err) {
        res.status(400).json({
            status: 'fail',
            message: err.message
        });
    }
};

exports.getResultPage = async (req, res) => {
    try {
        const result = await Result.findById(req.params.id)
            .populate('exam')
            .populate('student');

        if (!result) {
            return res.status(404).render('error', { message: 'Result not found' });
        }

        // Ensure only the student who took the exam or a teacher can view the result
        if (req.user.role !== 'teacher' && result.student._id.toString() !== req.user._id.toString()) {
            return res.status(403).render('error', { message: 'Unauthorized' });
        }

        res.render('result', { user: req.user, result });
    } catch (err) {
        res.status(500).render('error', { message: 'Error loading result' });
    }
};
